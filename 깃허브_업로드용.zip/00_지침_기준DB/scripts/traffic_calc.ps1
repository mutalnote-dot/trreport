﻿# 검토/영향평가 대상 판정 및 개략 교통수요 산정기 (PowerShell)
# 주의: 수요·주차 계수는 수도권 평균 참고 추정치이므로, 실제 보고서에는 반드시
#       관할 시 조례·교통지표(03_시별_자료/) 및 입력 자료 값을 우선 사용하십시오.
param (
    [double]$AptGfa = 32000,
    [double]$CommGfa = 1200,
    [int]$UnitsUnder50 = 40,
    [int]$Units50to85 = 180,
    [int]$UnitsOver85 = 30
)

Write-Host "===============================================" -ForegroundColor Cyan
Write-Host " [영향평가 대상 판정 및 교통수요 산정 결과] " -ForegroundColor Yellow
Write-Host "===============================================" -ForegroundColor Cyan

# 1. 대상 판정 (도촉법 별표1 기준)
$AptLimit = 60000
$CommLimit = 12000

$RatioApt = [math]::Round($AptGfa / $AptLimit, 4)
$RatioComm = [math]::Round($CommGfa / $CommLimit, 4)
$TotalRatio = [math]::Round($RatioApt + $RatioComm, 4)
$TotalGfa = $AptGfa + $CommGfa

Write-Host "[1] 대상 판정 (도촉법 시행령 별표1)" -ForegroundColor Green
Write-Host " - 아파트 연면적: $AptGfa ㎡ (기준: 60,000 ㎡, 비율: $RatioApt)"
Write-Host " - 근생 연면적: $CommGfa ㎡ (기준: 12,000 ㎡, 비율: $RatioComm)"
Write-Host " - 복합비율 합계: $TotalRatio (총 연면적: $TotalGfa ㎡)"

if ($TotalRatio -ge 1.0 -or $AptGfa -ge $AptLimit -or $CommGfa -ge $CommLimit) {
    Write-Host " >> 판정 결과: [영향평가(TIA) 심의 대상]" -ForegroundColor Red
} else {
    Write-Host " >> 판정 결과: [검토서(소규모정비/건축심의) 대상]" -ForegroundColor Cyan
}

# 2. 인구 및 발생교통량 산정
$TotalUnits = $UnitsUnder50 + $Units50to85 + $UnitsOver85
$Pop = ($UnitsUnder50 * 1.6) + ($Units50to85 * 2.4) + ($UnitsOver85 * 2.8)
$TripsRes = $Pop * 2.2
$TripsComm = ($CommGfa / 100.0) * 30.0
$TotalPersonTrips = [math]::Round($TripsRes + $TripsComm)

# 차량 발생교통량 (승용차 분담률 35%, 평균재차인원 1.25)
$DailyVehTrips = [math]::Round(($TotalPersonTrips * 0.35) / 1.25)

# 첨두시
$AmTotal = [math]::Round($DailyVehTrips * 0.105)
$AmIn = [math]::Round($AmTotal * 0.20)
$AmOut = [math]::Round($AmTotal * 0.80)

$PmTotal = [math]::Round($DailyVehTrips * 0.085)
$PmIn = [math]::Round($PmTotal * 0.70)
$PmOut = [math]::Round($PmTotal * 0.30)

# 법정 주차대수
$LegalParking = [math]::Round(($UnitsUnder50 * 0.8) + ($Units50to85 * 1.05) + ($UnitsOver85 * 1.3) + ($CommGfa / 134.0))
$RecParking = [math]::Round($LegalParking * 1.15)

Write-Host ""
Write-Host "[2] 교통수요 및 주차 추정" -ForegroundColor Green
Write-Host " - 총 세대수: $TotalUnits 세대 (활동인구: $([math]::Round($Pop, 1)) 명)"
Write-Host " - 1일 총 발생통행량: $TotalPersonTrips 인-통행/일"
Write-Host " - 1일 차량 발생교통량: $DailyVehTrips 대/일"
Write-Host " - 오전 첨두(08~09시): 총 $AmTotal 대/시 (유입 $AmIn 대, 유출 $AmOut 대)"
Write-Host " - 오후 첨두(18~19시): 총 $PmTotal 대/시 (유입 $PmIn 대, 유출 $PmOut 대)"
Write-Host " - 법정 주차대수 추정: $LegalParking 대 (권장 확보: $RecParking 대)"
Write-Host "===============================================" -ForegroundColor Cyan
