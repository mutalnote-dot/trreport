"""
영향평가 대상 판정 및 기본 교통수요/주차 개략 산정기 (Traffic Impact Calculator)
- 용도: 0단계 대상 판정 및 개략 규모 참고용
- 주의: 수요·주차 계수는 수도권 평균 참고 추정치이므로, 실제 보고서에는 반드시
  해당 시의 조례·교통지표(`03_시별_자료/`) 및 입력 자료 값을 우선 사용하십시오.
- 작성자: Antigravity AI
"""

import sys
import json

# 도촉법 시행령 별표1 기준 (도시교통정비지역 최소 대상 연면적, ㎡)
CRITERIA = {
    "아파트": 60000,
    "공동주택": 60000,
    "제1종근생": 12000,
    "제2종근생": 15000,
    "업무시설": 25000,
    "오피스텔": 25000,
    "판매시설": 11000,
    "숙박시설": 15000,
    "위락시설": 5000,
    "종교시설": 15000,
    "문화집회": 15000,
    "예식장": 3000,
    "공장": 75000,
    "창고": 55000,
}

def check_tia_screening(usages: list[dict]):
    """
    usages 예시: [{"type": "아파트", "gfa": 45000}, {"type": "제1종근생", "gfa": 1500}]
    """
    total_gfa = sum(u["gfa"] for u in usages)
    ratio_sum = 0.0
    details = []
    is_tia = False

    for u in usages:
        t = u["type"]
        gfa = u["gfa"]
        limit = CRITERIA.get(t, 25000)
        ratio = gfa / limit
        ratio_sum += ratio
        if gfa >= limit:
            is_tia = True
        details.append({
            "type": t,
            "gfa": gfa,
            "limit": limit,
            "ratio": round(ratio, 4)
        })

    if ratio_sum >= 1.0:
        is_tia = True

    return {
        "is_tia": is_tia,
        "ratio_sum": round(ratio_sum, 4),
        "total_gfa": total_gfa,
        "details": details,
        "recommendation": "영향평가(TIA) 심의 대상" if is_tia else "검토서(소규모/건축심의) 대상"
    }

def estimate_residential_traffic(
    units_under_50: int,
    units_50_to_85: int,
    units_over_85: int,
    commercial_gfa: float = 0.0,
    modal_split_auto: float = 0.35,
    car_occupancy: float = 1.25
):
    """
    공동주택 세대수 기반 활동인구 및 발생교통량(대/일, 대/시) 산정
    """
    # 1. 인구 산정
    pop_under_50 = units_under_50 * 1.6
    pop_50_to_85 = units_50_to_85 * 2.4
    pop_over_85 = units_over_85 * 2.8
    total_pop = pop_under_50 + pop_50_to_85 + pop_over_85
    total_units = units_under_50 + units_50_to_85 + units_over_85

    # 2. 주거 발생통행량 (1인당 2.2통행/일)
    trips_res = total_pop * 2.2

    # 3. 근생 발생통행량 (100㎡당 30통행/일)
    trips_comm = (commercial_gfa / 100.0) * 30.0

    total_person_trips = trips_res + trips_comm

    # 4. 차량 발생교통량 (대/일)
    total_veh_trips = (total_person_trips * modal_split_auto) / car_occupancy

    # 5. 첨두시간대 교통량
    # 오전첨두 (집중률 10.5%, In 20%, Out 80%)
    am_peak_total = total_veh_trips * 0.105
    am_in = round(am_peak_total * 0.20)
    am_out = round(am_peak_total * 0.80)

    # 오후첨두 (집중률 8.5%, In 70%, Out 30%)
    pm_peak_total = total_veh_trips * 0.085
    pm_in = round(pm_peak_total * 0.70)
    pm_out = round(pm_peak_total * 0.30)

    # 6. 법정 주차대수 추정
    parking_res = (units_under_50 * 0.8) + (units_50_to_85 * 1.05) + (units_over_85 * 1.3)
    parking_comm = commercial_gfa / 134.0
    total_legal_parking = round(parking_res + parking_comm)

    # 권장 주차수요 (법정의 115%)
    rec_parking = round(total_legal_parking * 1.15)

    return {
        "total_units": total_units,
        "total_pop": round(total_pop, 1),
        "total_person_trips": round(total_person_trips),
        "daily_veh_trips": round(total_veh_trips),
        "am_peak": {"in": am_in, "out": am_out, "total": am_in + am_out},
        "pm_peak": {"in": pm_in, "out": pm_out, "total": pm_in + pm_out},
        "legal_parking": total_legal_parking,
        "recommended_parking": rec_parking
    }

if __name__ == "__main__":
    # 간단 테스트
    sample_usages = [
        {"type": "아파트", "gfa": 32000},
        {"type": "제1종근생", "gfa": 1200}
    ]
    res_screening = check_tia_screening(sample_usages)
    print("=== 대상 판정 결과 ===")
    print(json.dumps(res_screening, ensure_ascii=False, indent=2))

    calc = estimate_residential_traffic(
        units_under_50=40,
        units_50_to_85=180,
        units_over_85=30,
        commercial_gfa=1200
    )
    print("\n=== 교통수요 및 주차 추정 결과 ===")
    print(json.dumps(calc, ensure_ascii=False, indent=2))
